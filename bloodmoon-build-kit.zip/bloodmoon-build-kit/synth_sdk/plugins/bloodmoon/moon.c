/* BLOODMOON screen: blood moon over a cathedral (bloodmoon.svg).
 *   blue  (BLOOD)    : the moon's colour, dim crimson -> vivid blood red
 *   green (ECLIPSE)  : a black disc slides across the moon from the right; at full only a thin red ring is left
 *   white (HAUNTING) : swing size of the bell in the left tower
 *   red   (MOONRISE) : swing speed of the bell
 * Four bars in the corners show the knob values in the OP-1 colours (blue, green | white, red).
 * GUI thread, integers only. Every node lookup is checked, so a missing id only disables that effect.
 * Copyright (C) 2026 Nola Drift. GPL-3.0-or-later with the OP-1 firmware permission (see LICENSE and NOTICE).
 * Screen structure follows the SDK examples (fmbell, brassophone) by pcppcp and nvmsocool. */
#include "op1_plugin.h"

#define MOON_CX        160
#define BELL_PX        99                 /* bell pivot, SVG units */
#define BELL_PY        62
#define SHADOW_START   84                 /* shadow x offset at the first touch of the moon, SVG units */
#define BAR_BASE_Y     152
#define BAR_MAX_LEN    44

static const uint8_t BAR_COL[4][4] = {
    { 0x4D, 0x9E, 0xFF, 0xFF },           /* blue  */
    { 0x00, 0xED, 0x95, 0xFF },           /* green */
    { 0xFF, 0xFF, 0xFF, 0xFF },           /* white */
    { 0xFF, 0x3A, 0x5D, 0xFF },           /* red   */
};
static const int BAR_X[4] = { 16, 28, 292, 304 };

static void *shadow_node, *bell_node;
static uint8_t *moon_rgba;                /* writable fill colour of the moon */
static uint32_t swing_q;                  /* swing phase in 1/256 table steps (8192 * 256 = one period) */

static inline int32_t tsin(int32_t a) { return OP1_SINE_TABLE[a & 8191]; }
static inline int32_t tcos(int32_t a) { return tsin(a + 2048); }

static void moon_init(void *scr)
{
    shadow_node = op1_find_node(scr, "shadow");
    bell_node = op1_find_node(scr, "bell");
    moon_rgba = op1_node_fill_rgba(scr, "moon");     /* the id exists and has a fill, so this is safe */
    swing_q = 0;
}

static inline int32_t lerp8(int32_t a, int32_t b, int32_t t_q15) { return a + (((b - a) * t_q15) >> 15); }

static void moon_update(void *scr, int dt)
{
    int16_t k[4];
    op1_synth_knobs_live(OP1_SCREEN_SLOT & 7, k);
    for (int i = 0; i < 4; i++) k[i] = k[i] < 0 ? 0 : k[i];          /* knobs are 0..32767 */
    if (dt < 1) dt = 1;
    if (dt > 100) dt = 100;                                          /* a stalled frame must not spin the bell */

    /* BLOOD: moon colour (0x4A,0x0A,0x14) -> (0xD0,0x14,0x2E) */
    if (moon_rgba) {
        moon_rgba[0] = (uint8_t)lerp8(0x4A, 0xD0, k[0]);
        moon_rgba[1] = (uint8_t)lerp8(0x0A, 0x14, k[0]);
        moon_rgba[2] = (uint8_t)lerp8(0x14, 0x2E, k[0]);
        moon_rgba[3] = 0xFF;
    }

    /* ECLIPSE: the shadow comes in from the right and ends centred on the moon; hidden while the knob is at the bottom */
    if (shadow_node) {
        int on = k[1] > 200;
        op1_node_set_visible(shadow_node, on);
        if (on) {
            int32_t dx_q10 = SHADOW_START * (1024 - (k[1] >> 5));        /* Q10: SHADOW_START .. ~0, 32-bit only */
            int32_t m[9] = { 1024, 0, 0, 0, 1024, 0, dx_q10, 0, 1024 };
            op1_node_set_transform(shadow_node, m);
        }
    }

    /* HAUNTING / MOONRISE: the bell. Speed about 0.2 .. 2 swings/s on a squared curve (dt assumed to be ms, as in
     * horn.c; if it is not, only the swing speed changes). Phase kept in 1/256 steps so slow speeds do not truncate to 0. */
    int32_t sq = (k[3] * k[3]) >> 15;
    swing_q += (uint32_t)(((3300 + sq) * dt) >> 3);
    if (bell_node) {
        int32_t amp = 40 + ((k[2] * 280) >> 15);                       /* 40..320 of 8192 = 1.8..14 degrees */
        int32_t a = (tsin((int32_t)(swing_q >> 8)) * amp) >> 15;
        op1_node_rotate(bell_node, OP1_Q10(BELL_PX), OP1_Q10(BELL_PY), tsin(a), tcos(a));
    }

    op1_screen_draw(scr, dt);                                        /* the SVG first: raster lines drawn before it are lost */

    void *r = op1_raster();
    for (int i = 0; i < 4; i++) {
        int32_t len = 2 + ((k[i] * (BAR_MAX_LEN - 2)) >> 15);
        op1_pt p0 = { OP1_Q10(BAR_X[i]), OP1_Q10(BAR_BASE_Y) };
        op1_pt p1 = { OP1_Q10(BAR_X[i]), OP1_Q10(BAR_BASE_Y - len) };
        op1_raster_line(r, &p0, &p1, OP1_Q10(3), BAR_COL[i]);
    }
}

const op1_screen_t SCREEN_bloodmoon = { moon_init, moon_update };
